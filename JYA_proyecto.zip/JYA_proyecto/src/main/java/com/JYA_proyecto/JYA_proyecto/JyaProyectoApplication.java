package com.JYA_proyecto.JYA_proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JyaProyectoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JyaProyectoApplication.class, args);
	}

}
